---
layout: post
title: 看看 RecyclerView
category: Android
tags:
  - Android
keywords:
  - Android
location: 青岛海尔
abbrlink: 7b3d9ef2
date: 2020-04-22 13:36:00
---

# 看看 RecyclerView  

	
## Recycler 回收池策略

[https://mp.weixin.qq.com/s/S31bHWLtUeR4-sjI-ULoUQ](https://mp.weixin.qq.com/s/S31bHWLtUeR4-sjI-ULoUQ)

[https://www.jianshu.com/p/efe81969f69d](https://www.jianshu.com/p/efe81969f69d)

- mAttachedScrap（ArrayList） 容量不限制，缓存的 ViewHolder 可直接使用，不需要重新绑定，目的是快速重用视图中的 ViewHolder
- mChangedScrap （ArrayList） 使用时需要走 bind 方法
- mCachedViews ArrayList 数量一般为2， 已经与 RecyclerView 脱离，但是数据还在
- mRecyclerPool 按照 itemType - ArrayList 存储，已经与 RecyclerView 脱离，完全重置，默认每种类型最多存5个
- ChildHelper mHiddenViews 缓存被隐藏的 ViewHolder


### tryGetViewHolderForPositionByDeadline
1.  getChangedScrapViewForPosition
2. getScrapOrHiddenOrCachedHolderForPosition
	- mAttachedScrap
	- mChildHelper mHiddenViews
	- mCachedViews
3.  getScrapOrCachedViewForId
4.  mViewCacheExtension
5. RecycledViewPool
6. createViewHolder

## ViewHolder 是干嘛用的


## RecyclerView 为什么比 ListView 更高效

[https://www.cnblogs.com/wytiger/p/10415402.html](https://www.cnblogs.com/wytiger/p/10415402.html)

ListView 两级缓存

|缓存|createView|bindView|生命周期|作用
|:--|:--|:--|:--|:--|
|mActiveViews|N|N|onLayout函数内|快速重用屏幕内的 View|
|mScrapViews|N|Y|与 Adapter 一致|

RecyclerView 四级缓存

|缓存|createView|bindView|生命周期|作用
|:--|:--|:--|:--|:--|
|mAttachScrap|N|N|onLayout函数内|快速重用屏幕内的 View|
|mChangedScrap|N|Y|onLayout函数内|存储修改的ViewHolder|
|mCacheViews|N|N|与 Adapter 一致, 当 Adapter 更换时，mCacheViews 即被缓存至 RecycerPool| 默认上限2+预取，缓存屏幕外的2个ViewHolder
|mViewCacheExtension||||用户定制
|mRecyclerPool|N|Y|不被引用时即被释放| 分类型，上限5
|mHiddenViews|N|N|动画作用时| 

## onLayout

1. dispatchLayoutStep1  记录更新之前的列表信息，用于动画计算
2. dispatchLayoutStep2 真正测量布局大小，位置，核心函数为layoutChildren()
3. dispatchLayoutStep3 计算前后状态变化，如有必要执行动画


## LayoutManager 如何实现

## RecyclerView 动画如何实现的

## RecyclerView Animation 如何实现的

## 如何优化

- 使用 `setHasFixedSize` 优化更新	

当我们确定Item的改变不会影响RecyclerView的宽高的时候可以设置setHasFixedSize(true)，并通过Adapter的增删改插方法去刷新RecyclerView，而不是通过notifyDataSetChanged()。

- 使用 `hasStableIds ` 优化回收和复用

回收时，如果为 true, 则所有的 ViewHolder 会直接进入 scrap 数组
复用时，如果为 true, 则使用 position 查找之后，又会使用 id 查找一遍，position  虽然不同，但是 id 相同意味着可以直接复用

