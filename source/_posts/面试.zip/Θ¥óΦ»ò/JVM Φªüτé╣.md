---
abbrlink: '0'
---
# JVM 要点

[https://mp.weixin.qq.com/s/8GTgs5Izdkbd4f9t7zn-bg](https://mp.weixin.qq.com/s/8GTgs5Izdkbd4f9t7zn-bg)
##  组成

1. 程序计数器 指向当前当前线程正在执行的字节码指令，线程私有
2. 虚拟机栈  用于执行方法的内存模型，每个方法被执行都会被压入栈，执行完推出栈（记录堆栈信息，栈溢出等），线程私有
3. 本地方法栈 调用本地 native 的内存模型，线程私有
4. 方法区  用于存储已被虚拟机加载的类信息、常量、静态变量、即时编译后的代码等数据，线程共享，包含运行时常量池
5. 堆（Heap）：Java对象存储的地方，线程共享，在虚拟机启动时创建，GC

## 共享内存模型（JMM）

多线程线程交互只能通过共享内存实现，线程的工作内存中保存了线程使用到的变量的拷贝，

## 堆

[https://blog.csdn.net/jisuanjiguoba/article/details/80156781](https://blog.csdn.net/jisuanjiguoba/article/details/80156781)

1. 新生代  使用复制清除算法，原因是每次 GC 都会回收大部分对象，包括一份 Eden 和 两份 Survivor 空间（8:1:1），清理时，扫描 Eden 和 A Survivor, 将 存活的对象 复制到空的 B Survivor 空间中，如果空间满，则复制到 老年代空间中，如果多次扫描仍然存活的对象，也会被移动到 老年代，清空 Eden 和 另一块 Survivor，交换 AB Survivor
2. 老年代 空间较大，对象存活时间长，采用标记整理算法，标记存活的对象，然后整理内存
3. 永久代   类定义、字节码和常量
4. MetaSpace 使用本地内存

## GC

1. 引用计数
2. 可达性分析 + finalize
3. GCRoot	虚拟机栈中引用的对象，方法区中静态属性、常量引用的对象，本地方法栈中 Native 方法引用的对象
4. 标记清除算法
5. 标记整理算法
6. 复制清除算法
7. 分代收集算法


1. Minor GC 回收新生代，经历过 Minor GC 存活的对象加1岁
2. Major GC 回收老年代，当 Eden 不够时触发
3. Full GC 回收整个新生代和老年代
4. 