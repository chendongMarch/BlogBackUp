---
layout: post
title: 看看 ARouter
category: Android
tags:
  - Android
keywords:
  - Android
location: 青岛海尔
abbrlink: fd7548ee
date: 2020-04-22 13:36:00
---


## 看看 ARouter 

## 基本技术点

- 使用 APT 自动生成 `路由收集类`，收集模块内的所有路由
- 使用 Transform 收集多模块中所有的 `路由收集类`
- 使用 ASM 自动生成代码，自动注册在 `_ARouter`  类中，完成路由注册