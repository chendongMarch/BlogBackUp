---
layout: post
title: 看看 OKHTTP
category: Android
tags:
  - Android
keywords:
  - Android
location: 青岛海尔
abbrlink: 887c2b1c
date: 2020-04-22 13:36:00
---


# OkHttp

## Dispatcher

## Interceptor

- Interceptors 自定义拦截，在网络连接之前
- RetryAndFollowUpInterceptor 负责请求重试和重定向，授权、30x的code，创建了 StreamAllocation
- BridgeInterceptor 追加 header, Gzip 传输，cookie
- CacheInterceptor 缓存实现
- ConnectInterceptor 使用 StreamAllocation 发起连接，返回  RealConnection
- networkInterceptors 自定义拦截，在网络连接之后
- CallServerInterceptor 开始请求，使用 okio 读取 buffer

## Interceptor 和 NetworkInterceptor

- addInterceptor（应用拦截器）：
位于请求链路的开始位置，这个时候请求还没有被 okhttp 处理
1. 不需要担心中间过程的响应,如重定向和重试.
2. 总是只调用一次,即使HTTP响应是从缓存中获取.
3. 观察应用程序的初衷. 不关心OkHttp注入的头信息如: If-None-Match.
4. 允许短路而不调用 Chain.proceed(),即中止调用.
5. 允许重试,使 Chain.proceed()调用多次.

- addNetworkInterceptor（网络拦截器）：
1. 能够操作中间过程的响应,如重定向和重试.
2. 当网络短路而返回缓存响应时不被调用.
3. 只观察在网络上传输的数据.
4. 携带请求来访问连接.


## 关键类

- RealConnection 物理连接 socket 的包装, `List<Reference<StreamAllocation>>` 是对这个 socket 的引用计数
- ConnectionPool 连接池，最大保留空闲连接 5个，最长时间 5 分钟，双端队列存储 RealConnection

## 缓存

## HTTP2

1. 多路复用，对于同一个域名的请求可以在同一条连接中并行进行
2. 二进制分帧，传输基于字节流，而不是文本，二进制分帧层在应用层和传输层之间
3. 头部压缩，
4. 服务端推送