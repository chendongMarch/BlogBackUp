---
abbrlink: '0'
---
# APT + ASM


ARouter 实现原理

1. 注解相关类
2. 使用 APT 每个模块的注解的类，被收集进 Group 类
3. 在编译期间使用 Transform  + ASM 插桩，自动插入初始化代码


Gradle+ASM

https://www.jianshu.com/p/16ed4d233fd1
