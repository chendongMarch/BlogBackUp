---
layout: post
title: Android Fragment
category: Android
tags:
  - Android
keywords:
  - Android
location: 青岛海尔
abbrlink: f0626deb
date: 2020-04-22 13:36:00
---

# 面试：Android - Fragment


## Framgent 生命周期

![](https://picture-pool.oss-cn-beijing.aliyuncs.com/006tKfTcgy1g16v654abfj30q619ctlr.jpg)

## 方法

show() 仅显示 View, 不走生命周期函数
hide() 仅隐藏 View, 不走生命周期函数
replace() 第一个 fragment onAttach(), 第二个 fragment onPause(),onDetach()
add() 执行 onAttach(),onResume()
remove() 执行 onPause(),onDetach()

## 添加无视图的 Fragment

使用 addFrament(Fragment, String)，不会回调 onCreateView() 方法

Fragment 和 Fragment 之间可以使用 

- setTargetFragment()
- sendResult()
- onActivityResult()

## Fragment onActivityResult

[](https://www.jianshu.com/p/2419329c7fe4)

- 单层嵌套时，如何保证 `onActivityResult` 能够执行？

1. 调用 `startActivityForResult` 时，不要使用 `getActivity(). startActivityForResult()`

2. 重写 `onActivityResult` 时，需要带有 `super. onActivityResult`

- 多层嵌套时无法正确分发

1. 重写 `onActivityResult` 方法，自己分发

## 交互

Handler
接口回调


## 为什么必须使用 Bundle 传参？

[分析](https://www.jianshu.com/p/c06efe090589)


因为 Android 在很多场景下都会出现 Fragment 的重建情况（比如横竖屏的切换），但是重建的时候系统并不会使用你编写的 Fragment 的构造方法而是调用 Fragment 默认的构造方法；重建时会走 Activity#onCreate(Bundle onSaveInstance) onSaveInstance 中存放着 Fragment 的 Bundle 数据，通过反射重新创建 Fragment 传入 Bundle 保证数据还能存在;