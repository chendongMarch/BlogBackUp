---
abbrlink: '0'
---
# 面试：Java 异常

```
Throwable - Error
Throwable - Exception
```


## Exception

可预测的异常，可以进行捕获，并针对异常做相应操作

- 检查性异常
	
	需要在编码时对异常进行捕捉，例如 IOException
	
- 非检查性异常
	
	不需要在编码时捕捉，例如 ArrayIndexOutOfBoundsException
	
## Error

不可预测异常，异常发生时，JVM 处于不可恢复的状态，所以不能捕获，

OutOfMemoryError, NoClassDefError


## Try-Catch

执行完try中的业务逻辑就，return返回的操作会先存储到一个临时的堆栈中，此时不给调用者返回，随后执行finally中的业务代码。如果finally中有return操作，那么就会把finally中的return值与try中的return值进行替换。随后将最终数据返回给调用者。

## 编码

1. 不要捕捉通用异常，异常的捕捉要精确
2. 不要忽略异常，应该打印或者收集
3. 提前抛出异常