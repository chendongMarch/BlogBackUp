---
abbrlink: '0'
---
# 面试：JS



## `Vue.js` 如何实现属性侦听自动更新？

[VueJs 深入响应式原理](https://cn.vuejs.org/v2/guide/reactivity.html)

- 利用 `defineProperty()` 定义 `getter/setter`
- 每个组件对应一个 Watcher
- `getter` 时，说明 `dom` 需要这个数据，加入依赖队列
- `setter` 时，说明数据有更新，通知 `Watcher`
- `Watcher` 管理更新的队列，在合适的时机发布这些更新


## 箭头函数和 `function` 的区别

- 写法不同，`function` 需要使用关键字，箭头函数相当于一个变量
- `this` 指向不同，`function` 作用域随着调用环境不同变化，箭头函数一直不变，一直指向定义箭头函数的上下文
- `function` 可以作为构造函数使用，箭头函数不能
- `function` 具备自动提升的特性，可以先使用后定义，但是箭头函数必须使用 `var/const/let` 不能自动提升